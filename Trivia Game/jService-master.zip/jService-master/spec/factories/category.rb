FactoryGirl.define do
  factory :category do
    title "Names of things"
    clues_count 1
  end
end
