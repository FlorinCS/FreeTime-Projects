PgSearch.multisearch_options = {
  using: {
    tsearch:    {dictionary: 'english'},
    trigram:    {threshold:  0.1},
    dmetaphone: {}
  }
}