# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
JArchive::Application.config.secret_token = '2e52da33ac4ab1c0cbb46551642039027e2d982008b1781cf57e4a0f07c29b5c14d04e60f622a9419f7908231760f9d515dce4d6ffc7be2b3daa6ec94394054c'
