//==========================//
//remember to run RAILS_ENV=production bundle exec rake assets:precompile
//==========================//
//==========================//

//= require jquery
//= require jquery_ujs
//= require bootstrap
//= require moment.min
//= require index
//= require popular
//= require api
//= require clues
//= require handlebars-v1.3.0
//= require handlebars-helpers


