module CluesHelper
end
