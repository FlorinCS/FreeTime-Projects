require 'test_helper'

class PopularHelperTest < ActionView::TestCase
end
