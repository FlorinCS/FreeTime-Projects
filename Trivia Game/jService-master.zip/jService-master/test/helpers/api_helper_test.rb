require 'test_helper'

class ApiHelperTest < ActionView::TestCase
end
