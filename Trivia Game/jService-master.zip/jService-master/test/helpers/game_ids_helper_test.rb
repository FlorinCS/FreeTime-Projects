require 'test_helper'

class GameIdsHelperTest < ActionView::TestCase
end
