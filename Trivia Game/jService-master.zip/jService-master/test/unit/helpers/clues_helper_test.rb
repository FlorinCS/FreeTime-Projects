require 'test_helper'

class CluesHelperTest < ActionView::TestCase
end
