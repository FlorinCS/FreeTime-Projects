require 'test_helper'

class ClueTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
